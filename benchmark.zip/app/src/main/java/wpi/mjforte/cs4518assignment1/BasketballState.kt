package wpi.mjforte.cs4518assignment1

class BasketballState(scoreTeamA: Int = 0, scoreTeamB: Int = 0) {

    var scoreTeamA: Int = scoreTeamA
        private set
    var scoreTeamB: Int = scoreTeamB
        private set

    fun reset() {
        scoreTeamA = 0
        scoreTeamB = 0
    }

    fun incrementTeamAScore(amount: Int) {
        scoreTeamA += amount
    }

    fun incrementTeamBScore(amount: Int) {
        scoreTeamB += amount
    }

}