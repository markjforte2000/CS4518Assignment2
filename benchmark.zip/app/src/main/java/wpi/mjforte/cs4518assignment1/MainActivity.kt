package wpi.mjforte.cs4518assignment1

import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.widget.Button

class MainActivity : AppCompatActivity() {

    private lateinit var controller: BasketballController

    val TEAM_A = "team_a"
    val TEAM_B = "team_b"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("Activity", "Init app")
        setContentView(R.layout.activity_main)
        // create controller
        val teamAPointsRaw : String? = savedInstanceState?.getString(TEAM_A)
        val teamBPointsRaw : String? = savedInstanceState?.getString(TEAM_B)
        controller = if (teamAPointsRaw != null && teamBPointsRaw != null) {
            Log.d("Activity", "Found $teamAPointsRaw points for team A and $teamBPointsRaw points for team B")
            BasketballController(this, teamAPointsRaw.toInt(), teamBPointsRaw.toInt())
        } else {
            BasketballController(this)
        }
        Log.d("Activity","Created app")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.run {
            putString(TEAM_A, controller.getTeamAScore().toString())
            putString(TEAM_B, controller.getTeamBScore().toString())
        }
        Log.d("Activity", "Saving Team A: " + outState.get(TEAM_A))
        Log.d("Activity", "Saving Team B: " + outState.get(TEAM_B))
        super.onSaveInstanceState(outState)
    }
}